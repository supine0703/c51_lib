/*
    This file is part of the c51_lib, see <https://github.com/supine0703/c51_lib>.
    
    Copyright (C) <2024>  <李宗霖>  <email: supine0703@outlook.com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

#ifndef __CONFIG___H
#define __CONFIG___H

#include <STC15.H>

#include "__type__.h"

/* ========================================================================== */

// 很多模块可能会用到, 所以放在 config 中申明
extern void _nop_(void);
extern void Delay5us(u8 t);
extern void Delay1ms(u16 t);

// lcd12864
#define LCD12864_DATA P0
#define LCD12864_RS  P2 ^ 0
#define LCD12864_RW  P2 ^ 1
#define LCD12864_EN  P2 ^ 2

// key_4x4
#define KEY_4X4_PIN P7
#define KEY_4X4_DELAY Delay1ms(5)

// ds18b20
#define DS18B20_DQ P1 ^ 7

// ds1302
#define DS1302_SCK P3 ^ 5
#define DS1302_SDA P3 ^ 6
#define DS1302_CE  P5 ^ 4

// hc_sr04
#define HC_SR04_TRIG P1 ^ 5
#define HC_SR04_ECHO P3 ^ 4

// i2c
#define I2C_SDA P6 ^ 6
#define I2C_SCL P6 ^ 7

// adc
#define VOLTAGE 3.3
#define LDR 0 // 光敏电阻 电位器P10

// 定义一些有用的宏函数
static u16 s_count_i;
#define FOR_C(I) for (s_count_i = (I); s_count_i; --s_count_i)


#endif // __CONFIG___H
