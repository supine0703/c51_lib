/*
    This file is part of the c51_lib, see <https://github.com/supine0703/c51_lib>.
    
    Copyright (C) <2024>  <李宗霖>  <email: supine0703@outlook.com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

#include "__config__.h"
#include "__function__.h"

u8 getKey(void);
void resetPassword(void);
void enterPassword(void);
void updateShow(void);
void showTime(void);
void showTemperature(void);
void TempMotorRun(bit s, u16 size);

u8 count_x1 = 0;
u8 count_t2 = 0;
u8 key;
u8 xdata buff[33];
u8 code date_time[] = {0, 0, 8, 27, 4, 6, 24};

#define PM_Z(P) (P##M0 = P##M1 = 0x00)                        // 置零
#define PPO(P, B) (P##M1 &= ~(1 << (B)), P##M0 |= (1 << (B))) // 推挽输出

void IO_Init()
{
    PM_Z(P0);
    PM_Z(P1);
    PM_Z(P2);
    PM_Z(P3);
    PM_Z(P4);
    PM_Z(P5);
    PM_Z(P6);
    PM_Z(P7);

    // LCD12864
    PPO(P2, 2);
    PPO(P2, 1);
    PPO(P2, 0);

    // 直流电机
    PPO(P1, 5); // 智慧农业
    PPO(P1, 6); // 智慧小车

    // 步进电机
    PPO(P1, 1);
    PPO(P1, 2);
    PPO(P1, 3);
    PPO(P1, 4); // 和智慧农业的红外冲突

    // 蜂鸣器
    PPO(P5, 5);
}

void INT_Init(void)
{
    AUXR &= 0xFB; // 定时器时钟12T模式
    T2L = 0xB0;   // 设置定时初始值
    T2H = 0x3C;   // 设置定时初始值
    AUXR |= 0x10; // 定时器2开始计时

    EA = 1;
    IE2 |= 0x04; // 定时器2中断

    IT1 = 1;
    EX1 = 1;
}

void main(void)
{
    IO_Init();
    INT_Init();
    LCD12864_Init();
    DS18B20_Convert();
    DS1320_SetRTC(date_time);


    if (KEY_4X4_Value() == 0x0f)
    {
        LCD12864_Cmd(0x80);
        LCD12864_String("About To");
        LCD12864_Cmd(0x90);
        LCD12864_String("Reset Password");
        while (KEY_4X4_Value() != 0xff)
            ;
        resetPassword();
    }

    enterPassword();

    while (1)
    {
        updateShow();

        if (getKey() != 0xff)
        {
            switch (key)
            {
            case 0:
                TempMotorRun(0, 512);
                break;
            case 1:
                TempMotorRun(1, 512);
                break;
            case 2:
                P15 = !P15;
                P16 = !P16;
                break;
            default:
                break;
            }
        }
    }
}

u8 getKey(void)
{
    key = KEY_4X4_Value();
    // while (1)
    // {
    //     if ((key | KEY_4X4_Value()) == 0xff)
    //     {
    //         Delay1ms(5);
    //         if ((key | KEY_4X4_Value()) == 0xff)
    //             break;
    //     }
    // } // 消抖 (其实没必要)
    while ((key | KEY_4X4_Value()) != 0xff)
        ;
    return key;
}

void resetPassword(void)
{
    bit loop = 1;
    u8 num;
    u8 i = 0, max = 8;
    LCD12864_Cmd(0x01);
    LCD12864_Cmd(0x80);
    LCD12864_String("New Password:");
    LCD12864_Cmd(0x90);
    LCD12864_Cmd(0x0e);
    while (loop)
    {
        num = 0xff;
        if (getKey() != 0xff)
        {
            switch (key)
            {
            case 0x00:
                num = 1;
                break;
            case 0x01:
                num = 2;
                break;
            case 0x02:
                num = 3;
                break;
            case 0x04:
                num = 4;
                break;
            case 0x05:
                num = 5;
                break;
            case 0x06:
                num = 6;
                break;
            case 0x08:
                num = 7;
                break;
            case 0x09:
                num = 8;
                break;
            case 0x0a:
                num = 9;
                break;
            case 0x0d:
                num = 0;
                break;
            case 0x03: // 退格
                if (i)
                {
                    buff[i] = 0;
                    LCD12864_Cmd(0x10);
                    LCD12864_String("  ");
                    i--;
                    LCD12864_Cmd(0x10);
                }
                break;
            case 0x0f: // 确认
                loop = 0;
                AT24C_Write(0x0000, &i, 1);
                AT24C_Write(0x0001, buff, i);
                break;
            default:
                break;
            }
            if (num != 0xff && i < max)
            {
                buff[i] = num + '0';
                LCD12864_Show(buff[i]);
                LCD12864_Show(0x20);
                buff[++i] = 0;
                num = 0xff;
            }
        }
    }
    LCD12864_Cmd(0x0c);
    LCD12864_Cmd(0x01);
}

void enterPassword(void)
{
    bit loop, lock = 1;
    u8 right, num, len, i;
    u8 max = 8; // 0-7
    while (lock)
    {
        loop = 1;
        right = 0;
        i = 0;
        AT24C_Read(0x0000, &len, 1);
        AT24C_Read(0x0001, buff + 9, len);
        LCD12864_Cmd(0x01);
        LCD12864_Cmd(0x80);
        LCD12864_String("Enter Password:");
        LCD12864_Cmd(0x90);
        LCD12864_Cmd(0x0e);
        while (loop)
        {
            num = 0xff;
            if (getKey() != 0xff)
            {
                switch (key)
                {
                case 0x00:
                    num = 1;
                    break;
                case 0x01:
                    num = 2;
                    break;
                case 0x02:
                    num = 3;
                    break;
                case 0x04:
                    num = 4;
                    break;
                case 0x05:
                    num = 5;
                    break;
                case 0x06:
                    num = 6;
                    break;
                case 0x08:
                    num = 7;
                    break;
                case 0x09:
                    num = 8;
                    break;
                case 0x0a:
                    num = 9;
                    break;
                case 0x0d:
                    num = 0;
                    break;
                case 0x03: // 退格
                    if (i)
                    {
                        buff[i] = 0;
                        LCD12864_Cmd(0x10);
                        LCD12864_String("  ");
                        if (right == i)
                        {
                            right--;
                        }
                        i--;
                        LCD12864_Cmd(0x10);
                    }
                    break;
                case 0x0f: // 确认
                    loop = 0;
                    break;
                default:
                    break;
                }
                if (num != 0xff && i < max)
                {
                    buff[i] = num + '0';
                    LCD12864_Show(buff[i]);
                    LCD12864_Show(0x20);
                    if (right == i)
                    {
                        right += ((buff[i] == buff[i + 9]) | (i >= len));
                    }
                    buff[++i] = 0;
                }
            }
        }
        LCD12864_Cmd(0x0c);
        LCD12864_Cmd(0x01);

        lock = (right != len);

        if (!lock)
        {
            LCD12864_String("Right Password");
        }
        else
        {
            LCD12864_String("Wrong Password");
            // buff[len + 9] = 0;
            // LCD12864_Cmd(0x90);
            // LCD12864_String(buff + 9);
        }
        LCD12864_Cmd(0x88);
        LCD12864_String("Enter Any Key...");
        while (getKey() == 0xff)
            ;
    }
    LCD12864_Cmd(0x01);
}

void updateShow(void)
{
    showTime();
    if (count_t2 > 20)
    {
        showTemperature();
        count_t2 = 0;

        sprintf(buff, "%02d", (u16)count_x1);
        LCD12864_Cmd(0x9f);
        LCD12864_String(buff);
        count_x1 = 0;

        sprintf(buff, "%4.2f", ADC_Result(LDR) * VOLTAGE / 1024);
        LCD12864_Cmd(0x86);
        LCD12864_String(buff); // 显示电压值
    }
}

void showTime(void)
{
    sprintf(
        buff,
        "20%02d-%02d-%02d",
        (u16)DS1320_ReadBCD(0x8d),
        (u16)DS1320_ReadBCD(0x89),
        (u16)DS1320_ReadBCD(0x87)
    );
    LCD12864_Cmd(0x80);
    LCD12864_String(buff);
    sprintf(
        buff,
        "%02dh %02dm %02ds",
        (u16)DS1320_ReadBCD(0x85),
        (u16)DS1320_ReadBCD(0x83),
        (u16)DS1320_ReadBCD(0x81)
    );
    LCD12864_Cmd(0x90);
    LCD12864_String(buff);
}

void showTemperature(void)
{
    EA = 0;
    sprintf(buff, "T: %6.2f C", DS18B20_ReadTemp());
    DS18B20_Convert();
    LCD12864_Cmd(0x98);
    LCD12864_String(buff);

    sprintf(buff, "D: %5.1f cm", HC_SR04_Result());
    LCD12864_Cmd(0x88);
    LCD12864_String(buff);
    EA = 1;
}

void TempMotorRun(bit s, u16 size)
{
    char i;
    u8 code spm_turn[] = {
        0x02,
        0x06,
        0x04,
        0x0c,
        0x08,
        0x09,
        0x01,
        0x03,
    };

    FOR_C(size)
    {
        if (s)
        {
            for (i = 0; i < 8; ++i)
            {
                P1 &= 0xe1;
                P1 |= spm_turn[i] << 1;
                Delay5us(255);
            }
        }
        else
        {
            for (i = 7; i >= 0; --i)
            {
                P1 &= 0xe1;
                P1 |= spm_turn[i] << 1;
                Delay5us(255);
            }
        }
    }
}

void int_x1(void) interrupt 2
{
    count_x1++;
}

void int_t2(void) interrupt 12
{
    count_t2++;
}
